import numpy as np
import matplotlib.pyplot as plt
import time
import mainSegmentation as sg
import DetectionSNF as dt
import utils
from skimage import feature
import cv2

# testing grab cut
def test_grab_cut(img_array):
    for i in np.arange(img_array.__len__()):
        print("image "+str(i+1)+"/"+str(img_array.__len__()))
        start_time = time.time()
        if len(img_array[i].shape) == 3:
            img_gray = img_array[i][:, :, 0]
        else:
            img_gray = img_array[i]
        plt.figure(i)
        (top, bottom, left, right) = sg.find_top_bottom_left_right(img_gray)
        sg.using_grab_cut(top, bottom, left, right, img_gray)
        elapsed_time = time.time() - start_time
        print("Execution time: " + str(int(elapsed_time / 60)) + " minute(s) and " + str(int(elapsed_time % 60)) + " seconds")
        print("image "+str(i+1)+"/"+str(img_array.__len__())+" done")


def test_segmentation(img_array, sigma, k, min_):
    for i in np.arange(img_array.__len__()):
        print("image "+str(i+1)+"/"+str(img_array.__len__()))
        start_time = time.time()
        if len(img_array[i].shape) == 3:
            img_gray = img_array[i][:, :, 0]
        else:
            img_gray = img_array[i]
        # Segmentation part -> to have plots , debug = 1
        (out_img, cropped_image, mask__) = sg.segment_image(img_gray, sigma, k, min_)

        # Converting RGB to Gray
        out_gray = utils.rgb_2_gray(out_img)

        #mask = utils.extract_mask_middle_layers(out_gray)
        # ploting
        utils.subplot(i + 1, cropped_image,out_img, out_gray, 'Cropped Image', 'Result of Graph based segmentation in RGB',
                      'Result of Graph based segmentation in gray', 1, 0, 1)
        #utils.subplot(i+1, out_img, out_gray, 'Result of Graph based segmentation in RGB',
        #          'Result of Graph based segmentation in gray', 0, 1, mask, np.multiply(cropped_image, mask),
        #          'Result middle layer mask', 'Appling mask to cropped_image', 1, 1)
        elapsed_time = time.time() - start_time
        print("Execution time: " + str(int(elapsed_time / 60)) + " minute(s) and " + str(int(elapsed_time % 60)) + " seconds")
        print("image "+str(i+1)+"/"+str(img_array.__len__())+" done")


def test_detection(img_array, sigma, k , min_):
    for i in np.arange(img_array.__len__()):
        print("image " + str(i + 1) + "/" + str(img_array.__len__()))
        start_time = time.time()
        if len(img_array[i].shape) == 3:
            img_gray = img_array[i][:, :, 0]
        else:
            img_gray = img_array[i]
        # Segmentation part -> to have plots , debug = 1
        (grabcut_image, cropped_image, grabcut_mask) = sg.segment_image(img_gray, sigma, k, min_)
        plt.figure(i + 19)
        plt.imshow(grabcut_image)
        plt.figure(i+20)
        plt.imshow(cropped_image)
        elapsed_time = time.time() - start_time
        print("Segmentation time: " + str(int(elapsed_time / 60)) + " minute(s) and " + str(int(elapsed_time % 60)) + " seconds")
        start_time = time.time()
        plt.figure(i + 21)
        dt.detect_SNF(grabcut_image, cropped_image, grabcut_mask)
        elapsed_time = time.time() - start_time
        print("Classification time: " + str(int(elapsed_time / 60)) + " minute(s) and " + str(int(elapsed_time % 60)) + " seconds")
        print("image "+str(i+1)+"/"+str(img_array.__len__())+" done")
        plt.show()

