from skimage import io
import matplotlib.pyplot as plt
import numpy as np
import random
import os.path
from scipy.misc import imread
import pdb


def extract_mask_middle_layers(img_gray_):
    img_to_work_ = np.multiply(img_gray_,255).astype('uint8')
    hist = np.histogram(img_to_work_, bins=np.arange(256))
    middle_layer_color = hist[1][np.argmax(hist[0])]
    found_mask = (img_to_work_ == middle_layer_color)
    return found_mask


def rgb_2_gray(img_):
    out_ = np.multiply(img_[:, :, 0], 0.3) + np.multiply(img_[:, :, 1], 0.59) + np.multiply(img_[:, :, 2], 0.11)
    out_ = np.multiply(out_, 255).astype('uint8')
    return out_

def subplot(figure_numero, plot_1, plot_2, plot_3,title1, title2, title3, op1, op2, op3):
    plt.figure(figure_numero)
    plt.subplot(1, 3, 1)
    plt.title(title1)
    if op1 == 0:
        plt.imshow(plot_1)
    else:
        plt.imshow(plot_1,cmap='gray')
    plt.subplot(1, 3, 2)
    plt.title(title2)
    if op2 == 0:
        plt.imshow(plot_2)
    else:
        plt.imshow(plot_2,cmap='gray')
    plt.subplot(1, 3, 3)
    plt.title(title3)
    if op3 == 0:
        plt.imshow(plot_3)
    else:
        plt.imshow(plot_3,cmap='gray')



